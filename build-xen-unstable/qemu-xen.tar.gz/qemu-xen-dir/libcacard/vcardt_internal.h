#ifndef VCARDT_INTERNAL_H
#define VCARDT_INTERNAL_H

unsigned char *vcard_alloc_atr(const char *postfix, int *atr_len);

#endif
