#include "qemu-common.h"
#include "sysemu/char.h"

CharDriverState *vc_init(ChardevVC *vc)
{
    return 0;
}
