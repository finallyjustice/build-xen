#include "qemu-common.h"
#include "block/block.h"

int bdrv_commit_all(void)
{
    return 0;
}
