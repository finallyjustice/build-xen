#include "qemu-common.h"
#include "sysemu/char.h"

CharDriverState *chr_testdev_init(void)
{
    return 0;
}
