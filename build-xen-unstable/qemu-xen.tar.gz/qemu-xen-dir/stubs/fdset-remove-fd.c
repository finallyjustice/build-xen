#include "qemu-common.h"
#include "monitor/monitor.h"

void monitor_fdset_dup_fd_remove(int dupfd)
{
}
