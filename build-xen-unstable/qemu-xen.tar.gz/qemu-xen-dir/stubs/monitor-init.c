#include "qemu-common.h"
#include "monitor/monitor.h"

void monitor_init(CharDriverState *chr, int flags)
{
}
