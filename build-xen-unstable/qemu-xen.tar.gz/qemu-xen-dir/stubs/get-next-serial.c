#include "qemu-common.h"

CharDriverState *serial_hds[0];
