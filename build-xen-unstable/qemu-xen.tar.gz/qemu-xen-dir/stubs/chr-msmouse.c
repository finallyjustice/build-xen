#include "qemu-common.h"
#include "sysemu/char.h"

CharDriverState *qemu_chr_open_msmouse(void)
{
    return 0;
}
