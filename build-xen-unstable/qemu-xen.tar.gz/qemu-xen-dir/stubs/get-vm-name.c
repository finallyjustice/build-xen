#include "qemu-common.h"

const char *qemu_get_vm_name(void)
{
    return NULL;
}

