#include "qemu-common.h"
#include "qemu/timer.h"

void qemu_clock_warp(QEMUClockType type)
{
}

