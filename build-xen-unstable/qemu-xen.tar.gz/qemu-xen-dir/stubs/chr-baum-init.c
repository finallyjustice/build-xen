#include "qemu-common.h"
#include "sysemu/char.h"

CharDriverState *chr_baum_init(void)
{
    return NULL;
}
