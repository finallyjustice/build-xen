#include "qemu-common.h"
#include "monitor/monitor.h"

int monitor_fdset_dup_fd_add(int64_t fdset_id, int dup_fd)
{
    return -1;
}
