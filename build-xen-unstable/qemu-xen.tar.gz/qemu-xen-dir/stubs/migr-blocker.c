#include "qemu-common.h"
#include "migration/migration.h"

void migrate_add_blocker(Error *reason)
{
}

void migrate_del_blocker(Error *reason)
{
}
