#include "qemu-common.h"
#include "monitor/monitor.h"

int monitor_fdset_dup_fd_find(int dup_fd)
{
    return -1;
}
