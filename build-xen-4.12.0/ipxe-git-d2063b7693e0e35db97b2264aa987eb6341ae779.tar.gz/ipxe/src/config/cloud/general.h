/* Allow retrieval of metadata (such as an iPXE boot script) from
 * Google Compute Engine metadata server.
 */
#define HTTP_HACK_GCE
